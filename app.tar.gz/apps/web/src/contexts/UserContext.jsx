
import React, { createContext, useContext, useState, useEffect } from 'react';
import { loadUserFromLocalStorage, saveUserToLocalStorage, clearUserData, checkAndUpdateStreak } from '@/lib/userStorage';

const UserContext = createContext(null);

export const UserProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [streak, setStreak] = useState({ current: 0, lastActive: null });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate 50ms delay for skeleton loaders
    const timer = setTimeout(() => {
      const loadedUser = loadUserFromLocalStorage();
      if (loadedUser) {
        setUser(loadedUser);
        setStreak(checkAndUpdateStreak());
      }
      setIsLoading(false);
    }, 50);
    return () => clearTimeout(timer);
  }, []);

  const updateUser = (updates) => {
    setUser(prev => {
      if (!prev) return prev;
      const newUser = { ...prev, ...updates };
      saveUserToLocalStorage(newUser);
      return newUser;
    });
  };

  const initializeNewUser = (name, level, subjects, examMonth, examYear) => {
    const newUser = {
      name,
      level,
      subjects,
      examMonth,
      examYear,
      apiKey: '',
      stats: { questionsSolved: 0, papersRead: 0, quizzesCompleted: 0, totalScore: 0, bySubject: {} },
      recentActivity: [],
      chatHistory: [],
      quizHistory: []
    };
    setUser(newUser);
    saveUserToLocalStorage(newUser);
    setStreak(checkAndUpdateStreak());
  };

  const addRecentActivity = (activity) => {
    setUser(prev => {
      if (!prev) return prev;
      const newActivity = [{ ...activity, id: Date.now() }, ...(prev.recentActivity || [])].slice(0, 10);
      const newUser = { ...prev, recentActivity: newActivity };
      saveUserToLocalStorage(newUser);
      return newUser;
    });
  };

  const clearUser = () => {
    clearUserData();
    setUser(null);
    setStreak({ current: 0, lastActive: null });
  };

  return (
    <UserContext.Provider value={{ 
      user, 
      streak,
      isLoading, 
      updateUser, 
      initializeNewUser, 
      addRecentActivity, 
      clearUser 
    }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};
